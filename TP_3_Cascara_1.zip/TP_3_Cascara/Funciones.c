#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#define ruta	"bin.dat"


int calcularTamanioArchivo()
{
    int tamanio=0; // declaro la variable que recibira el tamanio.
    FILE* arch; // declaro un puntero de tipo FILE.

    if ((arch=fopen(ruta, "r"))!=NULL)
	{
        fseek(arch, 0L, SEEK_END);           // me ubico en el final del archivo.
        tamanio=ftell(arch);
	}
    fclose(arch);// cierro el archivo.
    return tamanio;
}



EMovie* InicializarArrPelicula(int cantPelicula)
{
    EMovie* p;
    p = (EMovie*) malloc(cantPelicula*sizeof(EMovie));
    return p;

}


EMovie*  cargarPeliculaArr()
{

    EMovie* PeliculasExistentes;
    EMovie pel;
    FILE* bin;
    int cant=0;
    int cantPelicula=0;

    cantPelicula = (calcularTamanioArchivo(bin)/sizeof(EMovie));
    if ((bin=fopen(ruta,"rb"))==NULL)
	{
		printf("No se pudo abrir el archivo");
		exit(1);
	}

	PeliculasExistentes=InicializarArrPelicula(cantPelicula);

	while(!feof(bin))
	{
        cant=cant + fread(&pel,sizeof(EMovie),1,bin);

        PeliculasExistentes [(cant -1)] =pel;

	}

	fclose(bin);
	//getch();
	return PeliculasExistentes;
}

int AltaPeliculas()
{
    EMovie movie;
    int cantPel=0;

    printf("Ingrese Titulo de la pelicula: ");
    fflush(stdin);
    gets(movie.titulo);
    printf("Ingrese Genero de la pelicula: ");
    fflush(stdin);
    gets(movie.genero);
    printf("Ingrese Duracion: ");
    scanf("%d", &movie.duracion);
    printf("Ingrese Descripcion de la pelicula: ");
    fflush(stdin);
    gets(movie.descripcion);
    printf("Ingrese Puntaje: ");
    scanf("%d", &movie.puntaje);
    printf("Ingrese Link de imagen de la pelicula: ");
    fflush(stdin);
    gets(movie.linkImagen);

    movie.estado = 1;

    cantPel++;


    agregarPelicula(movie);

    return cantPel;
}

int agregarPelicula(EMovie movie)
{
    FILE  *bin;
	if ((bin=fopen(ruta,"a+b"))!=NULL)
	{
		fwrite(&movie,sizeof(movie),1,bin);

	}else
	{
		printf("El archivo no puede ser abierto");
		system("pause");
	}

	fclose(bin);

	return 0;
}

int BuscarPelicula(EMovie* peliculas, char titulo[50], int cantPel )
{
    int i;
    int pos=-1;
    for(i=0; i<cantPel;i++){

        if (strcmp((peliculas + i)->titulo,titulo)== 0){
            pos=i;
            break;
            }
    }
    return pos;
}

void bajarPeliculas(EMovie* ArrPel, int cantPel)
{
    char titulo [50];
    int pos;
    char s;

    do{
        printf("Ingrese titulo de la pelicula a borrar: \n");
        fflush(stdin);
        gets(titulo);

        pos = BuscarPelicula(ArrPel,titulo,cantPel);
        if (pos>0){
            (ArrPel+pos)->estado=0;
        }
        printf("Desea borrar otra pelicula (s/n) \n");
        fflush(stdin);
        s=getchar();
    }while (s!='n');

    borrarPeliculas(ArrPel,cantPel);


}

void borrarPeliculas(EMovie* ArrPel,int cantPel)
{
    FILE  *bin;
    int i;
	if ((bin=fopen(ruta,"wb"))!=NULL)
	{

	    for(i=0;i<cantPel;i++){
            if((ArrPel+i)->estado==1)
                fwrite((ArrPel+i),sizeof(EMovie),1,bin);
	    }
	}else
	{
		printf("El archivo no puede ser abierto");
		system("pause");
	}

	fclose(bin);

}

void generarPagina(EMovie* ArrPel, char nombre[50],int cantPel)
{
    char codigoHTML [5000];
    int i;
    char rutaImg[500];
    char titulo[50];
    char genero[50];
    char puntaje[5];
    char duracion[5];
    char descripcion[500];
    char encabezado[1100];
    char pie[400];
    int longi;

    strcpy(encabezado,"<!DOCTYPE html><!-- Template by Quackit.com --><html lang='en'><head><meta charset='utf-8'><meta http-equiv='X-UA-Compatible' content='IE=edge'><meta name='viewport' content='width=device-width, initial-scale=1'><!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags --><title>Lista peliculas</title><!-- Bootstrap Core CSS --><link href='css/bootstrap.min.css' rel='stylesheet'><!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles --><link href='css/custom.css' rel='stylesheet'><!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries --><!-- WARNING: Respond.js doesn't work if you view the page via file:// --><!--[if lt IE 9]><script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script><script src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js'></script><![endif]--></head><body><div class='container'><div class='row'>");
    strcpy(pie,"</div><!-- /.row --></div><!-- /.container --><!-- jQuery --><script src='js/jquery-1.11.3.min.js'></script><!-- Bootstrap Core JavaScript --><script src='js/bootstrap.min.js'></script><!-- IE10 viewport bug workaround --><script src='js/ie10-viewport-bug-workaround.js'></script><!-- Placeholder Images --><script src='js/holder.min.js'></script></body></html>");
    FILE  *bin2;
    longi=strlen (encabezado);
	if ((bin2=fopen(nombre,"w"))!=NULL)
	{
		fwrite(encabezado,sizeof(char),longi,bin2);

	}else
	{
		printf("El archivo no puede ser abierto");
		system("pause");
	}



    for(i=0;i<cantPel;i++){
        strcpy(codigoHTML,"  ");
        strcpy(titulo,(ArrPel + i)->titulo);
        strcpy(rutaImg,(ArrPel + i)->linkImagen);
        strcpy(genero,(ArrPel + i)->genero);
        sprintf(puntaje, "%i", (ArrPel + i)->puntaje);
        sprintf(duracion, "%i", (ArrPel + i)->duracion);
        strcpy(descripcion,(ArrPel + i)->descripcion);
        strcat(codigoHTML,"<article class='col-md-4 article-intro'><a href='#'><img class='img-responsive img-rounded' src='");
        strcat( codigoHTML, rutaImg );
        strcat( codigoHTML, "' alt=''></a><h3><a href='#'>" );
        strcat( codigoHTML, titulo );
        strcat( codigoHTML, "</a></h3><ul><li>Genero:" );
        strcat( codigoHTML, genero );
        strcat( codigoHTML, "</li><li>Puntaje:" );
        strcat( codigoHTML, puntaje );
        strcat( codigoHTML, "</li><li>Duracion:" );
        strcat( codigoHTML, duracion );
        strcat( codigoHTML, "</li></ul><p>" );
        strcat( codigoHTML, descripcion );
        strcat( codigoHTML, "</p></article>" );
        longi=strlen (codigoHTML);
        fwrite(codigoHTML,sizeof(char),longi,bin2);


    }

    longi=strlen (pie);
    fwrite(pie,sizeof(char),longi,bin2);
    fclose(bin2);

}
