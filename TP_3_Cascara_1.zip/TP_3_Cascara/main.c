#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"



int main()
{
    int cantPel=0;
    char seguir='s';
    int opcion=0;
    int tamanio=0;
    EMovie pel;
    EMovie* pel2;
    char nombre []="pagina.html";


    while(seguir=='s')
    {
        system("cls");
        printf("-----Administracion de Peliculas -------\n");
        printf("Elija una opcion:\n");
        printf("1- Agregar pelicula\n");
        printf("2- Borrar pelicula\n");
        printf("3- Generar pagina web\n");
        printf("4- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                system("cls");
                cantPel=AltaPeliculas();

                break;
            case 2:
                system("cls");
                pel2=cargarPeliculaArr();
                tamanio= calcularTamanioArchivo();
                cantPel= tamanio/sizeof(pel);

                bajarPeliculas(pel2,cantPel);

            break;
            case 3:
                system("cls");
                pel2=cargarPeliculaArr();
                tamanio= calcularTamanioArchivo();
                cantPel= tamanio/sizeof(pel);

                generarPagina(pel2,nombre,cantPel);
                system("pause");

                break;
            case 4:
                seguir = 'n';
                break;
        }
    }

    return 0;
}
