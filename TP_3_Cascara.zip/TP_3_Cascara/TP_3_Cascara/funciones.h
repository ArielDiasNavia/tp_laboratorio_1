#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct{
    char titulo[20];
    char genero[20];
    int duracion;
    char descripcion[1000];
    int puntaje;
    char linkImagen[500];
    int estado;
}EMovie;
/**
 *  calcula el tama�o del archivo
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna puntero al array de estructuras con las peliculas del archivo cargadas
 */
int calcularTamanioArchivo();

/**
 *  Carga las peliculas del archivo binario, es posible que la primera vez que se corra el programa el archivo no exista.
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna puntero al array de estructuras con las peliculas del archivo cargadas
 */
EMovie* cargarPeliculaArr();

/**
 *  Agrega una pelicula al archivo binario
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo agregar la pelicula o no
 */
//int AltaPeliculas(EMovie* ArrPel, int cantPel);

int AltaPeliculas();

/**
 *  Agrega una pelicula al archivo binario
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna cant bytes
 */
int agregarPelicula(EMovie movie);


/**
 *  Recibe el puntero a Emovie (lista de peliculas) y la cantidad da opcion de borrar peliculas
 *  @param movie la estructura a ser agregada al archivo
 *  @return void
 */
void bajarPeliculas(EMovie* ArrPel, int cantPel);

/**
 *  reescribe el archivo binario con las peliculas borradas (activo=0)
 *  @param movie la estructura a ser eliminada al archivo, cantidad de peliculas
 *  @return retorna 1 o 0 de acuerdo a si pudo eliminar la pelicula o no
 */
void borrarPeliculas(EMovie* ArrPel,int cantPel);

/**
 *  Genera un archivo html a partir de las peliculas cargadas en el archivo binario.
 *  @param lista la lista de peliculas a ser agregadas en el archivo.
 *  @param nombre el nombre para el archivo.
 */
void generarPagina(EMovie* peliculas, char nombre[],int cantPel);

/**
 *  Busca una pelicula en la lista de peliculas para ser eliminada mas adelante
 *  @param lista la lista de peliculas a ser agregadas en el archivo, el titulo de la pelicula y la cantidad
 *  @param nombre el nombre para el archivo.
 */
int BuscarPelicula(EMovie* peliculas, char titulo[50], int cantPel );

/**
 *  Inicializa el array de estructuras e inicialmente reserva memoria para 5 peliculas
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo agregar la pelicula o no
 */
EMovie* InicializarArrPelicula(int);


#endif // FUNCIONES_H_INCLUDED
